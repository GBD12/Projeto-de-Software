package com.projetousf.stockplusapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockplusapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockplusapiApplication.class, args);
	}

}
